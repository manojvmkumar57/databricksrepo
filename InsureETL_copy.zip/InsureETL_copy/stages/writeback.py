from pyspark.sql.types import DecimalType
from pyspark.sql.functions import col

class WriteBackStage:

    def __init__(self, es_conf, logger):
        self.es_conf = es_conf
        self.logger = logger

    def write_metrics(self, df):

        # Convert Decimal → Double
        for field in df.schema.fields:
            if isinstance(field.dataType, DecimalType):
                df = df.withColumn(field.name, col(field.name).cast("double"))

        # Write to Elasticsearch
        (df.write
            .format("org.elasticsearch.spark.sql")
            .option("es.nodes", self.es_conf["host"])
            .option("es.port", self.es_conf["port"])
            .option("es.resource", "insurance_metrics/_doc")
            .option("es.nodes.wan.only", "true")
            .mode("append")
            .save()
        )

        self.logger.info("Metrics written to Elasticsearch")

        # ✅ Write directly to HDFS (NO Hive)
        (df.write
            .mode("append")
            .parquet("/user/inceptez/insurance_metrics")
        )

        self.logger.info("Metrics written to HDFS")

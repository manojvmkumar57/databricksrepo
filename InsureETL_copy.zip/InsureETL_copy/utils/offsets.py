from pyspark.sql import Row
from pyspark.sql.functions import max as spark_max
from datetime import datetime


class OffsetManager:

    def __init__(self, spark, logger):
        self.spark = spark
        self.logger = logger
        self.offset_path = "/user/inceptez/etl_offsets"   # ✅ updated


    # Get last processed offset
    def get_last_offset(self, table):

        try:
            df = self.spark.read.parquet(self.offset_path)

            df = df.filter(f"table_name = '{table}'") \
                   .orderBy("inserted_ts", ascending=False) \
                   .limit(1)

            rows = df.collect()

            if len(rows) == 0:
                return 0

            return rows[0]["last_offset"]

        except Exception:
            return 0


    # Update offset
    def update_offset(self, table, pk, df):

        if df.rdd.isEmpty():
            self.logger.info(f"No new data for {table}")
            return

        max_pk = df.select(spark_max(pk)).first()[0]

        offset_row = Row(
            table_name=table,
            last_offset=int(max_pk),
            inserted_ts=datetime.now()
        )

        offset_df = self.spark.createDataFrame([offset_row])

        (offset_df.write
            .mode("append")
            .parquet(self.offset_path)
        )

        self.logger.info(f"Offset updated: {table} -> {max_pk}")
